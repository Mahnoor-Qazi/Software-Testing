package com.example.tdd;

import java.util.List;

public interface IBookRepository {
    List<Book> findAllBooks();
}
