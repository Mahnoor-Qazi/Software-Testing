package com.example.tdd;

import java.util.List;
import java.util.stream.Collectors;

public class BookService {
    private IBookRepository bookRepository;

    public BookService(IBookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<Book> getBooksByAuthor(String author) {
        if (author == null) {
            throw new IllegalArgumentException("Author cannot be null");
        }
        return bookRepository.findAllBooks().stream()
                .filter(book -> book.getAuthor() != null && book.getAuthor().equals(author))
                .collect(Collectors.toList());
    }

    public List<Book> getBooksByTitle(String title) {
        if (title == null) {
            throw new IllegalArgumentException("Title cannot be null");
        }
        return bookRepository.findAllBooks().stream()
                .filter(book -> book.getTitle() != null && book.getTitle().equals(title))
                .collect(Collectors.toList());
    }

    public List<Book> getBooksByAuthorAndTitle(String author, String title) {
        if (author == null || title == null) {
            throw new IllegalArgumentException("Author and title cannot be null");
        }
        return bookRepository.findAllBooks().stream()
                .filter(book -> book.getAuthor() != null && book.getAuthor().equals(author) &&
                        book.getTitle() != null && book.getTitle().equals(title))
                .collect(Collectors.toList());
    }
}