package com.example.tdd;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

public class BookServiceTest {

    private BookService bookService;

    @BeforeEach
    public void setup() {
        IBookRepository bookRepository = new BookRepository();
        bookService = new BookService(bookRepository);
    }

    @Test
    public void verifyBooksBySpecificAuthor() {
        List<Book> books = bookService.getBooksByAuthor("Kent Beck");
        Assertions.assertEquals(1, books.size(), "Book list size should be 1");
        Assertions.assertEquals("Test Driven Development", books.get(0).getTitle(), "Book title should be 'Test Driven Development'");
    }

    @Test
    public void verifyNoBooksReturnedForUnknownAuthor() {
        List<Book> books = bookService.getBooksByAuthor("Unknown Author");
        Assertions.assertTrue(books.isEmpty(), "Book list should be empty");
    }

    @Test
    public void verifyBooksBySpecificTitle() {
        List<Book> books = bookService.getBooksByTitle("Clean Code");
        Assertions.assertEquals(1, books.size(), "Book list size should be 1");
        Assertions.assertEquals("Robert C. Martin", books.get(0).getAuthor(), "Author should be 'Robert C. Martin'");
    }

    @Test
    public void verifyNoBooksReturnedForUnknownTitle() {
        List<Book> books = bookService.getBooksByTitle("Nonexistent Title");
        Assertions.assertTrue(books.isEmpty(), "Book list should be empty");
    }

    @Test
    public void verifyBooksByAuthorAndTitle() {
        List<Book> books = bookService.getBooksByAuthorAndTitle("Martin Fowler", "Refactoring");
        Assertions.assertEquals(1, books.size(), "Book list size should be 1");
        Assertions.assertEquals("Martin Fowler", books.get(0).getAuthor(), "Author should be 'Martin Fowler'");
        Assertions.assertEquals("Refactoring", books.get(0).getTitle(), "Title should be 'Refactoring'");
    }

    @Test
    public void verifyNoBooksReturnedForAuthorWithNonexistentTitle() {
        List<Book> books = bookService.getBooksByAuthorAndTitle("Kent Beck", "Nonexistent Title");
        Assertions.assertTrue(books.isEmpty(), "Book list should be empty");
    }

    @Test
    public void verifyNoBooksReturnedForUnknownAuthorAndExistingTitle() {
        List<Book> books = bookService.getBooksByAuthorAndTitle("Unknown Author", "Test Driven Development");
        Assertions.assertTrue(books.isEmpty(), "Book list should be empty");
    }

    @Test
    public void verifyExceptionThrownForNullAuthor() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            bookService.getBooksByAuthor(null);
        }, "Should throw IllegalArgumentException for null author");
    }

    @Test
    public void verifyExceptionThrownForNullTitle() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            bookService.getBooksByTitle(null);
        }, "Should throw IllegalArgumentException for null title");
    }

    @Test
    public void verifyExceptionThrownForNullAuthorWithExistingTitle() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            bookService.getBooksByAuthorAndTitle(null, "Test Driven Development");
        }, "Should throw IllegalArgumentException for null author");
    }

    @Test
    public void verifyExceptionThrownForExistingAuthorWithNullTitle() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            bookService.getBooksByAuthorAndTitle("Kent Beck", null);
        }, "Should throw IllegalArgumentException for null title");
    }

    @Test
    public void verifyExceptionThrownForNullAuthorAndTitle() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            bookService.getBooksByAuthorAndTitle(null, null);
        }, "Should throw IllegalArgumentException for null author and title");
    }
}
